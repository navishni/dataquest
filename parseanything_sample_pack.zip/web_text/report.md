# Annual Operations Report

## 1. Executive Summary

Sewage treatment plants operate through primary, secondary and tertiary stages. Influent is screened, equalised and biologically treated before clarification and disinfection. Operators must record flow, BOD, COD and TSS at defined intervals to demonstrate compliance. Sewage treatment plants operate through primary, secondary and tertiary stages. Influent is screened, equalised and biologically treated before clarification and disinfection. Operators must record flow, BOD, COD and TSS at defined intervals to demonstrate compliance. 

- Revenue grew 13.7% year-on-year to INR 61.2 Cr.
- Zero lost-time incidents across 10 sites.
- Effluent compliance achieved at 98.4% of sampling events.

## 2. Debt Schedule (first 5 rows)

| Lender | Facility | Sanctioned | Outstanding | Interest | Tenor |
|---|---|---:|---:|---:|---:|
| Indian Bank | Term Loan #1 | 381 | 347 | 9.58 | 3 |
| SBI | Working Capital #2 | 124 | 101 | 8.38 | 12 |
| HDFC Bank | BG Limit #3 | 109 | 96 | 8.86 | 4 |
| Axis Bank | Equipment Loan #4 | 494 | 253 | 8.96 | 11 |
| Canara Bank | Term Loan #5 | 484 | 118 | 10.26 | 6 |

## 3. Formulas

$$DSCR=\frac{NOI}{Debt\ Service}$$

```python
print('code')
```

![Revenue chart](chart.png)
