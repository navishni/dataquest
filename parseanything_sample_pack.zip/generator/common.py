import random
random.seed(7)
LENDERS=["Indian Bank","SBI","HDFC Bank","Axis Bank","Canara Bank"]
FACS=["Term Loan","Working Capital","BG Limit","Equipment Loan"]
ROWS=[]
for i in range(46):
    s=random.randint(50,900); o=int(s*random.uniform(0.2,0.95))
    ROWS.append([LENDERS[i%5],f"{FACS[i%4]} #{i+1}",s,o,round(random.uniform(8,12),2),random.randint(3,12)])
YRS=["FY22","FY23","FY24","FY25"]; REV=[42.5,48.1,53.9,61.2]; EBITDA=[9.8,11.4,13.0,15.7]
LOREM=("Sewage treatment plants operate through primary, secondary and tertiary stages. Influent is screened, equalised and biologically treated before clarification and disinfection. Operators must record flow, BOD, COD and TSS at defined intervals to demonstrate compliance. ")
BUL=["Revenue grew 13.7% year-on-year to INR 61.2 Cr.","Zero lost-time incidents across 10 sites.","Effluent compliance achieved at 98.4% of sampling events."]
