import random, shutil
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import *
F="/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"; FB="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
# phone photo of an invoice
pg=Image.new("RGB",(1100,1500),(250,250,246)); d=ImageDraw.Draw(pg)
f=ImageFont.truetype(F,34); fb=ImageFont.truetype(FB,46)
d.text((80,80),"TAX INVOICE",font=fb,fill=(20,20,20))
L=["Invoice No: INV-2026-0418","Date: 12.09.2026","","Item                         Qty    Rate      Amount","Blower service                 2    25,000    50,000","Sludge pump repair             1    40,000    40,000","","Subtotal                                       90,000","GST @ 18%                                      16,200","TOTAL (Rs.)                                  1,06,200"]
y=220
for l in L: d.text((80,y),l,font=f,fill=(30,30,30)); y+=62
bg=Image.new("RGB",(1600,2000),(110,80,55)); 
for _ in range(80000): bg.putpixel((random.randrange(1600),random.randrange(2000)),(random.randint(70,130),random.randint(50,95),random.randint(30,70)))
pg=pg.rotate(7,expand=True,fillcolor=(110,80,55)); bg.paste(pg,(150,150))
sh=Image.new("L",bg.size,0)
ph=bg.filter(ImageFilter.GaussianBlur(1.2)).resize((1200,1500)); ph.save("images/phone_photo_invoice.jpg",quality=60)
shutil.copy("scan.jpg","images/scanned_certificate.jpg"); Image.open("scan.jpg").convert("L").save("images/scanned_certificate.png")
shutil.copy("chart.png","images/chart_bar.png")
# table as picture
fig,ax=plt.subplots(figsize=(8,3.6),dpi=160); ax.axis("off")
tb=ax.table(cellText=[[r[0],r[1],f"{r[2]:,}",f"{r[3]:,}",r[4],r[5]] for r in ROWS[:10]],colLabels=["Lender","Facility","Sanctioned","Outstanding","Int %","Yrs"],loc="center"); tb.auto_set_font_size(False); tb.set_fontsize(8); tb.scale(1,1.3)
plt.savefig("images/table_picture.png",bbox_inches="tight"); plt.close()
c=Image.open("images/chart_bar.png").convert("RGB")
c.save("images/chart_bar.bmp"); c.save("images/chart_bar.gif"); c.save("images/chart_bar.webp")
a=Image.open("images/scanned_certificate.jpg").convert("RGB"); b=Image.open("images/table_picture.png").convert("RGB")
a.save("images/multipage_scan.tiff",save_all=True,append_images=[b],compression="tiff_deflate")
