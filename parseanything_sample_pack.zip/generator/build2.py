import os, csv, json
from common import *
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.chart import BarChart, Reference
from openpyxl.comments import Comment
for d in ("office","web_text","email","images","failure_cases"): os.makedirs(d,exist_ok=True)

wb=Workbook(); ws=wb.active; ws.title="Debt Schedule"
ws["A1"]="Debt Schedule - ACME Infrastructure Ltd."; ws.merge_cells("A1:F1"); ws["A1"].font=Font(name="Arial",bold=True,size=14)
hdr=[(3,1,"Lender"),(3,2,"Facility"),(3,3,"Amount (INR Lakh)"),(3,5,"Interest % p.a."),(3,6,"Tenor (Years)"),(4,3,"Sanctioned"),(4,4,"Outstanding")]
for r,c,v in hdr: ws.cell(r,c,v)
for rng in ("C3:D3","A3:A4","B3:B4","E3:E4","F3:F4"): ws.merge_cells(rng)
for r in (3,4):
    for c in range(1,7):
        x=ws.cell(r,c); x.font=Font(name="Arial",bold=True); x.fill=PatternFill("solid",fgColor="D9E2EF"); x.alignment=Alignment(horizontal="center",vertical="center")
for i,row in enumerate(ROWS):
    for j,v in enumerate(row): ws.cell(5+i,1+j,v)
last=4+len(ROWS); tot=last+1
ws.cell(tot,1,"TOTAL").font=Font(bold=True); ws.cell(tot,3,f"=SUM(C5:C{last})"); ws.cell(tot,4,f"=SUM(D5:D{last})")
ws.cell(tot+1,1,"Utilisation %"); ws.cell(tot+1,4,f"=D{tot}/C{tot}"); ws.cell(tot+1,4).number_format="0.0%"
ws.freeze_panes="A5"
for col,w in zip("ABCDEF",(16,22,14,14,14,12)): ws.column_dimensions[col].width=w
w2=wb.create_sheet("Financials")
w2.append(["Year","Revenue (INR Cr)","EBITDA (INR Cr)","EBITDA margin"])
for i,y in enumerate(YRS): w2.append([y,REV[i],EBITDA[i],f"=C{i+2}/B{i+2}"]); w2.cell(i+2,4).number_format="0.0%"
w2["A9"]="Second table on same sheet: Site capacity"; w2.append([]); 
w2["A10"]="Site"; w2["B10"]="Capacity (KLD)"
for i,(a,b) in enumerate([("Tuticorin",300),("Chandpur",300),("Paradeep",900),("Virudhunagar",5000)]): w2.cell(11+i,1,a); w2.cell(11+i,2,b)
bc=BarChart(); bc.type="col"; bc.title="Revenue and EBITDA, FY22-FY25"
bc.add_data(Reference(w2,min_col=2,max_col=3,min_row=1,max_row=5),titles_from_data=True); bc.set_categories(Reference(w2,min_col=1,min_row=2,max_row=5)); w2.add_chart(bc,"F2")
w3=wb.create_sheet("Notes"); w3["A1"]="Notes"; w3["A2"]="Effluent limits: BOD < 30 mg/L, TSS < 50 mg/L, pH 6.5-8.5."; w3["A2"].comment=Comment("Per CPCB norms","Auditor")
w3["A4"]="Dates stored as real dates:"; 
import datetime; w3["A5"]=datetime.date(2026,8,4); w3["A5"].number_format="DD.MM.YYYY"
w4=wb.create_sheet("HiddenSheet"); w4["A1"]="HIDDEN SHEET - parser should flag or skip"; w4.sheet_state="hidden"
wb.save("office/finance.xlsx")

# CSV / TSV / messy
hdrrow=["Lender","Facility","Sanctioned (INR Lakh)","Outstanding (INR Lakh)","Interest % p.a.","Tenor (Years)"]
with open("office/finance.csv","w",newline="",encoding="utf-8") as f: w=csv.writer(f); w.writerow(hdrrow); w.writerows(ROWS)
with open("office/finance.tsv","w",newline="",encoding="utf-8") as f: w=csv.writer(f,delimiter="\t"); w.writerow(hdrrow); w.writerows(ROWS)
with open("office/messy.csv","w",newline="",encoding="utf-8-sig") as f:
    f.write("ACME Infrastructure Ltd.;;;;;\nGenerated: 08.10.2026;;;;;\n;;;;;\n")
    w=csv.writer(f,delimiter=";"); w.writerow(["Lender","Facility, with comma","Sanctioned","Outstanding","Interest","Tenor"])
    for r in ROWS[:8]: w.writerow([r[0],f'"{r[1]}", note',str(r[2]).replace(".",","),r[3],str(r[4]).replace(".",","),r[5]])
    f.write(";;;;;\nTotal;;;;;\nthis row has only 2 cols;x\n")

# web/text
tbl="".join(f"<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]:,}</td><td>{r[3]:,}</td><td>{r[4]}</td><td>{r[5]}</td></tr>" for r in ROWS[:12])
import base64; b64=base64.b64encode(open("chart.png","rb").read()).decode()
html=f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Annual Operations Report</title><style>.nav{{background:#eee}}</style><script>var tracking=1;</script></head><body>
<div class="nav"><a href="#">Home</a> | <a href="#">About</a> | Cookie banner: we use cookies</div>
<h1>Annual Operations Report</h1><h2>1. Executive Summary</h2><p>{LOREM*2}</p><ul>{''.join(f'<li>{b}</li>' for b in BUL)}</ul>
<h2>2. Debt Schedule</h2><table border="1"><thead><tr><th rowspan="2">Lender</th><th rowspan="2">Facility</th><th colspan="2">Amount (INR Lakh)</th><th rowspan="2">Interest % p.a.</th><th rowspan="2">Tenor</th></tr><tr><th>Sanctioned</th><th>Outstanding</th></tr></thead><tbody>{tbl}</tbody></table>
<h2>3. Financial Performance</h2><img alt="Revenue and EBITDA bar chart" src="data:image/png;base64,{b64}">
<h2>4. Formula</h2><math><mi>DSCR</mi><mo>=</mo><mfrac><mi>NOI</mi><mi>Debt Service</mi></mfrac></math>
<pre>print("code block")</pre><footer>&copy; ACME 2026 - boilerplate footer to exclude</footer></body></html>"""
open("web_text/report.html","w",encoding="utf-8").write(html)
md="# Annual Operations Report\n\n## 1. Executive Summary\n\n"+LOREM*2+"\n\n"+"\n".join("- "+b for b in BUL)+"\n\n## 2. Debt Schedule (first 5 rows)\n\n| Lender | Facility | Sanctioned | Outstanding | Interest | Tenor |\n|---|---|---:|---:|---:|---:|\n"+"\n".join(f"| {r[0]} | {r[1]} | {r[2]:,} | {r[3]:,} | {r[4]} | {r[5]} |" for r in ROWS[:5])+"\n\n## 3. Formulas\n\n$$DSCR=\\frac{NOI}{Debt\\ Service}$$\n\n```python\nprint('code')\n```\n\n![Revenue chart](chart.png)\n"
open("web_text/report.md","w",encoding="utf-8").write(md); 
open("web_text/report.txt","w",encoding="utf-8").write("ANNUAL OPERATIONS REPORT\n\n1. EXECUTIVE SUMMARY\n"+LOREM*2+"\n\n"+"\n".join("* "+b for b in BUL)+"\n\nLender          Facility            Sanctioned  Outstanding\n"+"\n".join(f"{r[0]:<15} {r[1]:<19} {r[2]:>10} {r[3]:>12}" for r in ROWS[:6])+"\n")
json.dump({"company":"ACME Infrastructure Ltd.","fy":"2025-26","financials":[{"year":y,"revenue_cr":REV[i],"ebitda_cr":EBITDA[i]} for i,y in enumerate(YRS)],"debt":[dict(zip(["lender","facility","sanctioned","outstanding","interest","tenor"],r)) for r in ROWS[:5]]},open("web_text/data.json","w"),indent=2)
x="<?xml version='1.0' encoding='utf-8'?><report company='ACME'><financials>"+"".join(f"<year name='{y}'><revenue>{REV[i]}</revenue><ebitda>{EBITDA[i]}</ebitda></year>" for i,y in enumerate(YRS))+"</financials></report>"
open("web_text/data.xml","w").write(x)

# eml
from email.message import EmailMessage
m=EmailMessage(); m["From"]="K. Gandhi <ops@sainath.example>"; m["To"]="accounts@client.example"; m["Cc"]="md@client.example"; m["Subject"]="RE: RE: FY25-26 Operations Report - handover & retention"; m["Date"]="Tue, 04 Aug 2026 10:15:00 +0530"; m["Message-ID"]="<abc123@sainath.example>"; m["In-Reply-To"]="<prev99@client.example>"
m.set_content("Dear Sir,\n\nPlease find attached the debt schedule and revenue chart.\nRetention amount pending: Rs. 4,25,000/-.\n\nRegards,\nK. Gandhi\n\n> On 03 Aug 2026, Accounts wrote:\n> Kindly share the schedule before Friday.\n")
m.add_alternative("<html><body><p>Dear Sir,</p><p>Please find attached the <b>debt schedule</b> and revenue chart.</p><table border='1'><tr><th>Item</th><th>Amount</th></tr><tr><td>Retention</td><td>Rs. 4,25,000/-</td></tr></table><p>Regards,<br>K. Gandhi</p><blockquote>On 03 Aug 2026, Accounts wrote:<br>Kindly share the schedule before Friday.</blockquote></body></html>",subtype="html")
m.add_attachment(open("office/finance.csv","rb").read(),maintype="text",subtype="csv",filename="debt_schedule.csv")
m.add_attachment(open("chart.png","rb").read(),maintype="image",subtype="png",filename="revenue_chart.png")
open("email/sample.eml","wb").write(bytes(m))
