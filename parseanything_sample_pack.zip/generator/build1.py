import os
from common import *
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
os.makedirs("office",exist_ok=True)

# ---------- DOCX ----------
d=Document()
sec=d.sections[0]
sec.header.paragraphs[0].text="ACME Infrastructure Ltd. - Annual Operations Report FY2025-26 | CONFIDENTIAL - SAMPLE"
fp=sec.footer.paragraphs[0]; fp.add_run("Page ")
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); fp._p.append(fld)
d.add_heading("Annual Operations Report",0)
d.add_heading("1. Executive Summary",1); d.add_paragraph(LOREM*2)
d.add_heading("1.1 Key Highlights",2)
for b in BUL: d.add_paragraph(b,style="List Bullet")
d.add_heading("1.2 Next Steps",2)
for b in ["Commission Unit 3 tertiary treatment.","Submit extension-of-time application.","Close out pending retention claims."]: d.add_paragraph(b,style="List Number")
d.add_heading("2. Process Description (two-column section)",1)
s2=d.add_section(WD_SECTION.CONTINUOUS)
c=OxmlElement('w:cols'); c.set(qn('w:num'),'2'); c.set(qn('w:space'),'360'); s2._sectPr.append(c)
for i in range(8): d.add_paragraph(LOREM*2)
d.add_paragraph("Footnote 1: Limits per CPCB discharge norms, as amended.")
s3=d.add_section(WD_SECTION.CONTINUOUS)
for x in s3._sectPr.findall(qn('w:cols')): s3._sectPr.remove(x)
d.add_heading("3. Debt Schedule",1)
d.add_paragraph("Table 1 continues across pages; header is 2 rows with merged cells.")
t=d.add_table(rows=2+len(ROWS),cols=6); t.style="Table Grid"
t.cell(0,2).merge(t.cell(0,3)); t.cell(0,0).merge(t.cell(1,0)); t.cell(0,1).merge(t.cell(1,1)); t.cell(0,4).merge(t.cell(1,4)); t.cell(0,5).merge(t.cell(1,5))
for (r,cc),v in {(0,0):"Lender",(0,1):"Facility",(0,2):"Amount (INR Lakh)",(0,4):"Interest % p.a.",(0,5):"Tenor (Years)",(1,2):"Sanctioned",(1,3):"Outstanding"}.items(): t.cell(r,cc).text=v
for i,row in enumerate(ROWS):
    for j,v in enumerate(row): t.cell(i+2,j).text=f"{v:,}" if j in(2,3) else str(v)
for r in (0,1):
    trPr=t.rows[r]._tr.get_or_add_trPr(); h=OxmlElement('w:tblHeader'); trPr.append(h)
d.add_heading("4. Financial Performance",1)
d.add_picture("chart.png",width=Inches(5.5)); d.add_paragraph("Figure 1: Revenue and EBITDA, FY22-FY25")
d.add_heading("5. Key Formulas (native Word equations)",1)
M='xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"'
eqs=[f'<m:oMathPara {M}><m:oMath><m:r><m:t>DSCR=</m:t></m:r><m:f><m:num><m:r><m:t>NOI</m:t></m:r></m:num><m:den><m:r><m:t>Debt Service</m:t></m:r></m:den></m:f></m:oMath></m:oMathPara>',
 f'<m:oMathPara {M}><m:oMath><m:r><m:t>NPV=</m:t></m:r><m:nary><m:naryPr><m:chr m:val="∑"/><m:limLoc m:val="undOvr"/></m:naryPr><m:sub><m:r><m:t>t=0</m:t></m:r></m:sub><m:sup><m:r><m:t>n</m:t></m:r></m:sup><m:e><m:f><m:num><m:sSub><m:e><m:r><m:t>C</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub></m:num><m:den><m:sSup><m:e><m:r><m:t>(1+r)</m:t></m:r></m:e><m:sup><m:r><m:t>t</m:t></m:r></m:sup></m:sSup></m:den></m:f></m:e></m:nary></m:oMath></m:oMathPara>',
 f'<m:oMathPara {M}><m:oMath><m:r><m:t>σ=</m:t></m:r><m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e><m:f><m:num><m:r><m:t>1</m:t></m:r></m:num><m:den><m:r><m:t>N</m:t></m:r></m:den></m:f><m:r><m:t>∑(xi−μ)2</m:t></m:r></m:e></m:rad></m:oMath></m:oMathPara>']
for e in eqs:
    p=d.add_paragraph(); p._p.append(parse_xml(e))
d.save("office/report.docx")

# ---------- PPTX ----------
from pptx import Presentation
from pptx.util import Inches as I, Pt as P
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_SHAPE
pr=Presentation(); pr.slide_width=I(13.333); pr.slide_height=I(7.5)
s=pr.slides.add_slide(pr.slide_layouts[0]); s.shapes.title.text="Annual Operations Report"; s.placeholders[1].text="ACME Infrastructure Ltd. - FY2025-26"
s.notes_slide.notes_text_frame.text="Speaker note: welcome and agenda."
s=pr.slides.add_slide(pr.slide_layouts[1]); s.shapes.title.text="Key Highlights"
tf=s.placeholders[1].text_frame; tf.text=BUL[0]
for b in BUL[1:]: tf.add_paragraph().text=b
s.notes_slide.notes_text_frame.text="Speaker note: stress the compliance figure 98.4%."
s=pr.slides.add_slide(pr.slide_layouts[5]); s.shapes.title.text="Debt Schedule (first 10 facilities)"
gt=s.shapes.add_table(12,6,I(0.6),I(1.6),I(12),I(5)).table
gt.cell(0,2).merge(gt.cell(0,3)); gt.cell(0,0).merge(gt.cell(1,0)); gt.cell(0,1).merge(gt.cell(1,1)); gt.cell(0,4).merge(gt.cell(1,4)); gt.cell(0,5).merge(gt.cell(1,5))
for (r,cc),v in {(0,0):"Lender",(0,1):"Facility",(0,2):"Amount (INR Lakh)",(0,4):"Interest % p.a.",(0,5):"Tenor (Years)",(1,2):"Sanctioned",(1,3):"Outstanding"}.items(): gt.cell(r,cc).text=v
for i,row in enumerate(ROWS[:10]):
    for j,v in enumerate(row): gt.cell(i+2,j).text=f"{v:,}" if j in(2,3) else str(v)
for r in gt.rows:
    for cell in r.cells:
        for p in cell.text_frame.paragraphs:
            for run in p.runs: run.font.size=P(12)
s=pr.slides.add_slide(pr.slide_layouts[5]); s.shapes.title.text="Revenue and EBITDA (native chart)"
cd=CategoryChartData(); cd.categories=YRS; cd.add_series("Revenue (INR Cr)",REV); cd.add_series("EBITDA (INR Cr)",EBITDA)
ch=s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED,I(1),I(1.6),I(11),I(5.4),cd).chart
ch.has_legend=True; ch.legend.position=XL_LEGEND_POSITION.BOTTOM; ch.legend.include_in_layout=False
ch.plots[0].has_data_labels=True
s=pr.slides.add_slide(pr.slide_layouts[5]); s.shapes.title.text="Chart as picture (no data behind it)"
s.shapes.add_picture("chart.png",I(2.5),I(1.5),width=I(8))
s=pr.slides.add_slide(pr.slide_layouts[5]); s.shapes.title.text="Process Flow (grouped shapes)"
g=s.shapes.add_group_shape()
for k,name in enumerate(["Screening","Biological","Clarifier","Disinfection"]):
    b=g.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,I(0.6+k*3.2),I(3),I(2.3),I(1.2)); b.text_frame.text=name
    if k<3: g.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW,I(2.95+k*3.2),I(3.35),I(0.55),I(0.5))
s=pr.slides.add_slide(pr.slide_layouts[5]); s.shapes.title.text="Scanned annexure (image only)"
s.shapes.add_picture("scan.jpg",I(4.2),I(1.4),height=I(5.9))
pr.save("office/deck.pptx")
