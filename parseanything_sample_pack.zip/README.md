# ParseAnything - Sample Document Pack (DataQuest 3.0)

Every file carries the same fictional "ACME Infrastructure Ltd. - Annual Operations Report FY2025-26" content, so one set of
assertions works across formats. All data is synthetic.

## Shared ground truth
- Revenue (INR Cr): FY22 42.5, FY23 48.1, FY24 53.9, FY25 61.2
- EBITDA  (INR Cr): FY22 9.8, FY23 11.4, FY24 13.0, FY25 15.7
- Debt schedule: 46 facilities, 2-row merged header (Lender | Facility | Amount (INR Lakh) -> Sanctioned, Outstanding | Interest % p.a. | Tenor)
  - Totals: Sanctioned = 21,185; Outstanding = 11,985; Utilisation = 56.6%
- Highlights: 3 bullets (revenue +13.7% to INR 61.2 Cr; zero lost-time incidents; 98.4% effluent compliance); 3 numbered next steps
- Equations: DSCR = NOI / Debt Service; NPV = sum_{t=0..n} C_t/(1+r)^t; sigma = sqrt(1/N * sum (x_i - mu)^2)
- Running header/footer text must NOT appear in body: "ACME Infrastructure Ltd. - Annual Operations Report FY2025-26", "CONFIDENTIAL - SAMPLE", page numbers

## Folder guide
| Path | What it tests |
|---|---|
| pdf/sample_test_document.pdf (+ .expected.json) | 8 pages: lists, 2-column order, sidebar, footnote, 48-row table across pages 4-5, chart + equations (images) on p6, image-only scan on p8 |
| office/report.docx | Headings, lists, 2-column section, header/footer, merged-cell table (48 rows, repeating header), chart picture, 3 native Word equations (OMML) |
| office/report.doc / .rtf / .odt | Legacy and open-format versions of the same report |
| office/deck.pptx | 7 slides: title, bullets + speaker notes, merged-cell table, NATIVE chart (data extractable exactly), chart as picture, grouped-shape flow diagram, scanned image slide |
| office/deck.ppt / .odp | Legacy / open versions |
| office/finance.xlsx | 4 sheets: merged-header debt table + SUM formulas, financials + native chart + 2nd table on same sheet, notes with cell comment and real date (04.08.2026), HIDDEN sheet |
| office/finance.xls / .ods | Legacy / open versions |
| office/finance.csv / .tsv | Clean flat table, 46 rows |
| office/messy.csv | Semicolon delimiter, UTF-8 BOM, junk title rows, decimal commas, embedded commas in quotes, ragged final row |
| web_text/report.html | rowspan/colspan table, base64 chart, MathML, nav/cookie/footer boilerplate and a script to exclude |
| web_text/report.md, report.txt, report.epub | Markdown (table, LaTeX, code fence), plain text with space-aligned table, EPUB |
| web_text/data.json, data.xml | Structured data pass-through |
| email/sample.eml | multipart: text + HTML alternatives, CSV and PNG attachments, quoted reply chain, Cc, In-Reply-To. Expect "Rs. 4,25,000/-" retention amount |
| images/scanned_certificate.jpg / .png | Skewed, noisy, low-quality scan. Expect "Total retention amount: Rs. 4,25,000/-"; 4 items, sludge pump "Under repair" |
| images/phone_photo_invoice.jpg | Photo of an invoice on a desk, tilted. Expect INV-2026-0418, 12.09.2026, Subtotal 90,000, GST 16,200, TOTAL 1,06,200 |
| images/table_picture.png | Table rendered as a picture (no text layer) - table reconstruction from pixels |
| images/chart_bar.png / .bmp / .gif / .webp | Same bar chart with value labels, in 4 raster formats |
| images/multipage_scan.tiff | 2-page TIFF: scanned certificate + table picture |
| failure_cases/* | See below |

## failure_cases - expected behaviour: structured error (no crash/hang), returned in < 60 s
| File | Suggested error code |
|---|---|
| empty_zero_bytes.pdf | EMPTY_FILE |
| corrupt_truncated.pdf, corrupt_garbage.pdf | CORRUPT_FILE |
| truncated.docx | CORRUPT_FILE (broken ZIP) |
| unsupported.xyz | UNSUPPORTED_FORMAT |
| pdf_renamed_as.docx | extension/content mismatch -> detect by magic bytes and parse as PDF (or FORMAT_MISMATCH warning) |
| text_renamed_as.pdf | FORMAT_MISMATCH / CORRUPT_FILE (not a PDF) |
| password_protected_pw_test123.pdf | PASSWORD_PROTECTED (password: test123, first 2 pages of the sample) |

## Not included
.msg, .xlsm, .heic and Apple iWork formats could not be produced reliably with the available tools. generator/ holds the scripts that built this pack.
